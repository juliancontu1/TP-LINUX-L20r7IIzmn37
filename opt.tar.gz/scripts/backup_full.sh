#!/bin/bash

#Aca se crea el help
# Opción de ayuda
if [ "$1" = "-help" ] || [ "$1" = "--help" ]; then
    echo "Uso: $0 ORIGEN DESTINO"
    echo
    echo "ORIGEN : directorio a backupear (por ejemplo /var/logs o /www_dir)"
    echo "DESTINO: directorio donde se guarda el backup (por ejemplo /backup_dir)"
    echo
    echo "El archivo generado se llama:"
    echo "  <nombre_origen>_bkp_YYYYMMDD.tar.gz"
    echo "Ejemplo:"
    echo "  log_bkp_20240302.tar.gz"
    exit 0
fi



# Se Valida cantidad de parámetros, si son menos o mas de 2 tira error
if [ $# -ne 2 ]; then
    echo "Se requieren exactamente 2 parámetros: ORIGEN y DESTINO."
    exit 1
fi

ORI="$1"
DES="$2"
#Se validan las entradas que realmente existan en la VM.
if [ ! -d "$ORI" ]; then
    echo "El directorio de origen '$ORI' no existe"
    exit 1
fi

if [ ! -d "$DES" ]; then
    echo "El directorio de destino'$DES' no existe"
    exit 1
fi

#FORMATO DE FECHA SOLICITADO:

FECHA=$(date +%Y%m%d)


#Como se van a guardar los archivos:

NOMBRE="basename $ORI_bkp_${FECHA}.tar.gz"
RUTA_BACKUP="${DEST}/${NOMBRE}"

#Se hace el backup:
tar -czpf "$RUTA_BACKUP" -C "$ORIGEN" .